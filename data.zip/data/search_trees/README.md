# Search trees

Data for search tree algorithms.

## What is it?

1. `insert_words.txt`: words to insert into the search three.
1. `not_insert_words.txt`: words not to insert, but to be used
   to test that they are not found in the search tree.
1. `corncob_lowercase.txt`: list of over 50,000 English words,
   all lower case (http://www.mieliestronk.com/corncob_lowercase.txt).
